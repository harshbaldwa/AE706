For running the shell script, first type this in the command terminal
    chmod +x final.sh

After this, following results would be obtained.

- For convergence history, use this command
    ./final.sh 1

- For number of steps, use this command
    ./final.sh 2

- For finding the optimum solution, use this command
    .final.sh 3

- For plotting the midlines results, use this command
    - For PJ, use
        ./final.sh 4 1
    - For PGS, use
        ./final.sh 4 2
    - For PSOR, use
        ./final.sh 4 3

- For contour plotting, use this command
    - For PJ, use
        ./final.sh 5 1
    - For PGS, use
        ./final.sh 5 2
    - For PSOR, use
        ./final.sh 5 3

For any clarification, please contact me @ +91-7742895101