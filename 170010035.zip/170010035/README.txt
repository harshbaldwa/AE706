Report is named Report.pdf in the main folder. All the codes are in the codes/ folder and plots in the plots/ folder. 

For running the shell script, first type this in the command terminal
    chmod +x plot.sh

    - After this, following results would be obtained.
	
	./plot.sh 1

    - To plot the comparison with the analytical solution, 

	./plot.sh 2

For any clarification, please contact me @ +91-7742895101
